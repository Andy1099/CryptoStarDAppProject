For this project I had to use the Goerli testnet because Rinkeby is not available for the time. 

ERC-721 Token Name: StarNotary
ERC-721 Token Symbol:STRN
“Token Address” on the Goerli Network: 0xebB0B167E1789C313F8630B8fa1719c8863e8D87
Truffle version: v5.5.1 (core: 5.5.1)
OpenZeppelin version: openzeppelin-solidity@4.6.0
Ganache version: v7.0.1
Solidity version: - 0.8.0 (solc-js)
Node version: v10.24.1
Web3.js version: v1.5.3*/
